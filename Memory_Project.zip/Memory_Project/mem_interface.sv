//--> Implementation of memory_interface:-

interface mem_interface(input reg clk_i,rst_i); 
//--> Design related Signlas Declared inside the Interface:-
	logic wr_rd_i,valid_i;
	logic [ADDR_WIDTH-1:0] addr_i;
	logic [WIDTH-1:0] wdata_i;
	logic [WIDTH-1:0] rdata_o;
	logic ready_o;
	int tx_count=0;

//--> BFM Clocking block:-
	//--> design input's declared as output
	//--> design output's declared as input
	clocking bfm_cb@(posedge clk_i); 
		default input #0 output #1; 
		input ready_o,rdata_o;
		output wr_rd_i,valid_i,addr_i,wdata_i;
	endclocking

//--> Monitor Clocking block:-
	clocking mon_cb@(posedge clk_i); 
		default input #1;
		input ready_o,rdata_o;
		input wr_rd_i,valid_i,addr_i,wdata_i;
	endclocking
	
	property handshake; 
		@(posedge clk_i) valid_i==1 |-> ready_o==1 ; 
	endproperty 
	HANDSHAKE_PRTY:assert property(handshake);

	property wr_rd; 
		@(posedge clk_i) (valid_i==1 && ready_o==1) |=> (wr_rd_i==1 || wr_rd_i==0); 
	endproperty 
	WR_RD_PRTY:assert property(wr_rd);

	property address; 
		@(posedge clk_i) (wr_rd_i==1 || wr_rd_i==0) |=> (!$isunknown(addr_i)); 
	endproperty 
	ADDRESS_PRTY:assert property(address);

	property write_data; 
		@(posedge clk_i) wr_rd_i==1 |=> (!$isunknown(wdata_i)); 
	endproperty 
	WRITE_DATA_PRTY:assert property(write_data);

	property read_data; 
		@(posedge clk_i) wr_rd_i==0 |=> (!$isunknown(rdata_o)); 
	endproperty 
	read_DATA_PRTY:assert property(read_data);
endinterface
