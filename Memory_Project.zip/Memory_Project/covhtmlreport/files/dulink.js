var g_data = {"1":["work.list_svh_unit",49.08,1],"3":["work.mem_interface",76.21,1],"4":["work.memory",81.37,1],"2":["work.top",69.23,1]};
processDuLinks(g_data);