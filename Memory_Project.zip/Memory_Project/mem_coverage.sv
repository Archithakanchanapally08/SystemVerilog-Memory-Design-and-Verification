//--> Implementation of memory_coverage:-

class mem_coverage;
	mem_tx tx;

	covergroup mem_cg; 
	    WR_RD_CP:coverpoint tx.wr_rd 
		 {
		 	bins WRITE = {1'b1};	
		 	bins READ = {1'b0};	
		 }

		ADDR_CP:coverpoint tx.addr
		{
			option.auto_bin_max = 16;
		}

		WR_RD_X_ADDR_CP:cross WR_RD_CP,ADDR_CP;
	endgroup 

	function new();
		mem_cg = new();
	endfunction

	task run();
		if(mem_common::verbosity >= HIGH)$display("\t--> Inside the Run_task of MEMORY_COVERAGE"); 	
		forever begin 
			mem_common::mon2cov.get(tx);
			mem_cg.sample();
		end
	endtask
	
endclass
