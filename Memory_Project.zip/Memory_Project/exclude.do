coverage exclude -scope /top -togglenode rst_i
coverage exclude -scope /top/dut -togglenode i
