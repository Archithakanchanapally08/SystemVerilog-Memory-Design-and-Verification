//--> Implementation of memory_tx:-

class mem_tx;
//--> Properties:- 
	rand bit wr_rd;
	randc bit[ADDR_WIDTH-1:0] addr;
	rand bit[WIDTH-1:0] wdata;
	     bit[WIDTH-1:0] rdata;

//--> Methods:- 
	function void print(string str="MEM_TX");
		$display("****************************| %0t_ns |*********************************",$time()); 
		$display("\t--> Printing the data from | %0s |",str); 
		$display("\t--> TX_Type:- %0s",wr_rd?"WRITE":"READ"); 	
		$display("\t--> Address:- %0h",addr); 
		$display("\t--> Write_data:- %0h",wdata); 
		$display("\t--> Read_data:- %0h",rdata); 
	endfunction

 //--> Constraints:-
 	constraint cst_n 
	 {
	 	soft wr_rd == 1'b1; //--> By default it will perform Write operation only.
	 }
endclass
