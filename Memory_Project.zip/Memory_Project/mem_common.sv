//--> Common file:-

parameter DEPTH = 16;
parameter WIDTH = 16;
parameter ADDR_WIDTH = $clog2(DEPTH);

`define COUNT 16

typedef enum bit[1:0]{NONE,LOW,MEDIUM,HIGH} verbo_ty;

class mem_common;
	static verbo_ty verbosity = HIGH;
	static string testname;
	static int gen_count,bfm_count;

	static mailbox gen2bfm = new();
	static mailbox mon2cov = new();
	static mailbox mon2sbd = new();

	static int num_matches,num_missmatches;
endclass
