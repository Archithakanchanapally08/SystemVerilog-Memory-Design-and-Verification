//--> Implementation of memory_agent:-

class mem_agent;
	mem_generator gen = new();
	mem_bfm		  bfm = new();
	mem_monitor   mon = new();
	mem_coverage  cov = new();

	task start();
	if(mem_common::verbosity >= HIGH)$display("\t--> Inside the Run_task of MEMORY_AGENT"); 
		fork 
			gen.run();
			bfm.run();
			mon.run();
			cov.run();
		join
	endtask
endclass
