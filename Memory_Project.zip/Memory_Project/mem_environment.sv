//--> Implementation of memory_environment:-

class mem_environment;
	mem_agent 		agent = new();
	mem_scoreboard 	sbd   = new();

	task run();
	if(mem_common::verbosity >= HIGH)$display("\t--> Inside the Run_task of MEMORY_ENVIRONMENT"); 	
		fork 
			sbd.run();
			agent.start();
		join
	endtask
endclass
