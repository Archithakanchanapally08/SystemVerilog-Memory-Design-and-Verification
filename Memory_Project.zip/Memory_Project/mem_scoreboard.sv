//--> Implementation of memory_scoreboard:-

class mem_scoreboard;
	mem_tx tx;
	int memAA[*];

	task run();
	if(mem_common::verbosity >= HIGH)$display("\t--> Inside the Run_task of MEMORY_SCOREBOARD"); 	
		forever begin 
			mem_common::mon2sbd.get(tx);
			if(mem_common::verbosity >= MEDIUM)tx.print(">>>> MEM_SBD <<<<");
			if(tx.wr_rd==1) memAA[tx.addr] = tx.wdata;		
			else begin  
				if(tx.rdata == memAA[tx.addr]) mem_common::num_matches++;
				else mem_common::num_missmatches++;
			end
		end
	endtask
endclass
