//--> Implementation of memory_monitor:-

class mem_monitor;
	mem_tx tx;
	virtual mem_interface vif;

	function new();
		vif = top.pif;
		tx = new();
	endfunction

	task run();
		if(mem_common::verbosity >= HIGH)$display("\t--> Inside the Run_task of MEMORY_MONITOR"); 	
		forever begin 
			@(vif.mon_cb);
			if(vif.mon_cb.valid_i==1 && vif.mon_cb.ready_o==1)begin 
				tx.wr_rd = vif.mon_cb.wr_rd_i;				
				tx.addr = vif.mon_cb.addr_i;				
				if(vif.mon_cb.wr_rd_i==1) tx.wdata = vif.mon_cb.wdata_i;
				else tx.wdata = 0;
				if(vif.mon_cb.wr_rd_i==0) begin 
					@(vif.mon_cb);
					tx.rdata = vif.mon_cb.rdata_o;
				end
				mem_common::mon2sbd.put(tx);
				mem_common::mon2cov.put(tx);
				if(mem_common::verbosity >= MEDIUM)tx.print("MEM_MON");
			end
		end
	endtask
endclass
