//--> Implementation of top_module:-

module top;
	reg clk_i,rst_i;

//--> mem_interface instanciatation
	mem_interface pif(clk_i,rst_i);
	mem_environment env;

//--> DUT Port connections:-
	memory #(.DEPTH(DEPTH),.WIDTH(WIDTH)) dut(
												.clk_i		(pif.clk_i),
												.rst_i		(pif.rst_i),
												.wr_rd_i	(pif.wr_rd_i),
												.addr_i		(pif.addr_i),
												.wdata_i	(pif.wdata_i),
												.rdata_o	(pif.rdata_o),
												.valid_i	(pif.valid_i),
												.ready_o	(pif.ready_o));

	//--> Clock_Generation:-
		//--> Freq = 100MHZ | tp = 10ns | duty_cyle = 50%
	initial begin  
		clk_i=0; 
		forever #5 clk_i=~clk_i; 
	end

	//--> Appling & Releasing Reset:-
	initial begin  
		if(mem_common::verbosity >= HIGH)$display("\t--> Inside the TOP_MODULE"); 
		rst_i=1; 
		reset_task();
		repeat(2)@(posedge clk_i);
		rst_i=0; 
		assert($value$plusargs("testname=%s",mem_common::testname));
		env = new();
		env.run();
	end

//--> Reset task of design input signals to avoid the unknown states
	task reset_task();
		pif.wr_rd_i = 0;
		pif.addr_i  = 0;
		pif.wdata_i = 0;
		pif.valid_i = 0;
	endtask

	//--> Ending the Simulation:-
	initial begin  
		//#50;
		//wait(2*(mem_common::gen_count) == mem_common::bfm_count);
		//#50;
		#500;
		$display("\n********************************************************************"); 
		$display("\t--> Passing Testcase name: | %0s |",mem_common::testname); 
		$display("\t--> Passing Count Value:- %0d",`COUNT); 
		$display("\t--> GEN_COUNT:- %0d || BFM_COUNT:- %0d",mem_common::gen_count,mem_common::bfm_count); 
		if(mem_common::num_matches==`COUNT && mem_common::num_missmatches==0)
			$display("\t--> TEST_PASSED: Num_matches:- %0d || Num_missmatches:- %0d",mem_common::num_matches,mem_common::num_missmatches); 
		else 
			$display("\t--> TEST_FAILED: Num_matches:- %0d || Num_missmatches:- %0d",mem_common::num_matches,mem_common::num_missmatches); 
		$display("********************************************************************"); 
		$printtimescale();
		//$finish(2); 
		$stop(2); 
	end
endmodule
