#--> Compilation:-
vlog list.svh

set testcase_name "test_nwr"

#--> Optimization:-
vopt work.top +cover=fcbest -o $testcase_name

#--> Elaboration:-
vsim -coverage $testcase_name +testname=$testcase_name

#--> Save the coverage report:-
coverage save -onexit $testcase_name.ucdb

#--> Adding the waveform:-
#add wave -position insertpoint sim:/top/pif/*
do wave.do
do exclude.do

#--> Simulation:-
run -all
