//--> Implementation of memory_generator:-

class mem_generator;
	mem_tx tx,temp,txQ[$];

	task run();
	if(mem_common::verbosity >= HIGH)$display("\t--> Inside the Run_task of MEMORY_GENERATOR"); 	
		case(mem_common::testname) 
			"test_1wr":begin
				tx = new();
				assert(tx.randomize());
				mem_common::gen2bfm.put(tx);
				mem_common::gen_count++;
				if(mem_common::verbosity >= MEDIUM)tx.print("MEM_GEN");
			end
			"test_5wr":begin
				repeat(5)begin
					tx = new();
					assert(tx.randomize());
					mem_common::gen2bfm.put(tx);
					mem_common::gen_count++;
					if(mem_common::verbosity >= MEDIUM)tx.print("MEM_GEN");
				end
			end
			"test_nwr":begin
				repeat(`COUNT)begin
					tx = new();
					assert(tx.randomize());
					mem_common::gen2bfm.put(tx);
					mem_common::gen_count++;
					if(mem_common::verbosity >= MEDIUM)tx.print("MEM_GEN");
				end
			end
			"test_1wr_1rd":begin
				tx = new();
				assert(tx.randomize());
				mem_common::gen2bfm.put(tx);
				mem_common::gen_count++;
				temp = new tx;
				txQ.push_back(temp);
				if(mem_common::verbosity >= MEDIUM)tx.print("MEM_GEN");

				tx = new();
				temp = txQ.pop_front();
				assert(tx.randomize() with {tx.wr_rd==0; tx.addr==temp.addr;});
				mem_common::gen2bfm.put(tx);
			end
			"test_5wr_5rd":begin
				repeat(5)begin
					tx = new();
					assert(tx.randomize());
					mem_common::gen2bfm.put(tx);
					temp = new tx;
					txQ.push_back(temp);
					mem_common::gen_count++;
					if(mem_common::verbosity >= MEDIUM)tx.print("MEM_GEN");
				end

				repeat(5)begin
					tx = new();
					temp = txQ.pop_front();
					assert(tx.randomize() with {tx.wr_rd==0; tx.addr == temp.addr;});
					mem_common::gen2bfm.put(tx);
				end
			end
			"test_nwr_nrd":begin
				repeat(`COUNT)begin
					tx = new();
					assert(tx.randomize());
					mem_common::gen2bfm.put(tx);
					temp = new tx;
					txQ.push_back(temp);
					mem_common::gen_count++;
					if(mem_common::verbosity >= MEDIUM)tx.print("MEM_GEN");
				end

				repeat(`COUNT)begin
					tx = new();
					temp = txQ.pop_front();
					assert(tx.randomize() with {tx.wr_rd==0; tx.addr == temp.addr;});
					mem_common::gen2bfm.put(tx);
				end
			end
			"test_unq_addr_loc":begin
				tx = new();
				repeat(`COUNT)begin
					assert(tx.randomize());
					temp = new tx;
					mem_common::gen2bfm.put(temp);
					txQ.push_back(temp);
					mem_common::gen_count++;
					if(mem_common::verbosity >= MEDIUM)tx.print("MEM_GEN");
				end

				repeat(`COUNT)begin
					tx = new();
					temp = txQ.pop_front();
					assert(tx.randomize() with {tx.wr_rd==0; tx.addr == temp.addr;});
					mem_common::gen2bfm.put(tx);
				end
			end
		endcase
	endtask
endclass
