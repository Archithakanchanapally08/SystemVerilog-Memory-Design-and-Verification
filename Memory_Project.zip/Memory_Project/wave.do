onerror {resume}
quietly WaveActivateNextPane {} 0
add wave -noupdate /top/pif/clk_i
add wave -noupdate /top/pif/rst_i
add wave -noupdate -group Handshake /top/pif/valid_i
add wave -noupdate -group Handshake /top/pif/ready_o
add wave -noupdate -group Data -radix unsigned /top/pif/tx_count
add wave -noupdate -group Data /top/pif/wr_rd_i
add wave -noupdate -group Data -radix unsigned /top/pif/addr_i
add wave -noupdate -group Data /top/pif/wdata_i
add wave -noupdate -group Data /top/pif/rdata_o
add wave -noupdate -group Assertions /top/pif/HANDSHAKE_PRTY
add wave -noupdate -group Assertions /top/pif/WR_RD_PRTY
add wave -noupdate -group Assertions /top/pif/ADDRESS_PRTY
add wave -noupdate -group Assertions /top/pif/WRITE_DATA_PRTY
add wave -noupdate -group Assertions /top/pif/read_DATA_PRTY
TreeUpdate [SetDefaultTree]
WaveRestoreCursors {{Cursor 1} {42321 ps} 0}
quietly wave cursor active 1
configure wave -namecolwidth 150
configure wave -valuecolwidth 100
configure wave -justifyvalue left
configure wave -signalnamewidth 1
configure wave -snapdistance 10
configure wave -datasetprefix 0
configure wave -rowmargin 4
configure wave -childrowmargin 2
configure wave -gridoffset 0
configure wave -gridperiod 1
configure wave -griddelta 40
configure wave -timeline 0
configure wave -timelineunits ns
update
WaveRestoreZoom {0 ps} {525 ns}
