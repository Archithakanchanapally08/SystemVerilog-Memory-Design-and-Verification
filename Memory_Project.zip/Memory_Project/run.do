#--> Compilation:-
vlog list.svh

#--> Elaboration:- 
vsim -voptargs="+acc" top +testname=test_1wr_1rd \
-sv_seed 2200 -assertdebug

#--> Adding the waveform:-
#add wave -position insertpoint sim:/top/pif/*
do wave.do

#--> Simulation:-
run -all 
