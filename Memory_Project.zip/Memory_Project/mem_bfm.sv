//--> Implementation of memory_bfm:-

class mem_bfm;
	mem_tx tx;
	virtual mem_interface vif;

	function new();
		vif = top.pif; //--> Copy by handle pif --> VIF
	endfunction

	task run();
		if(mem_common::verbosity >= HIGH)$display("\t--> Inside the Run_task of MEMORY_BFM"); 	
		//$display("\t--> Inside the Run_task of MEMORY_BFM"); 	
		forever begin 
			mem_common::gen2bfm.get(tx);
			if(vif.tx_count==`COUNT) vif.tx_count = 1;
			else vif.tx_count++;
			drive_tx(tx);
			mem_common::bfm_count++;
			if(mem_common::verbosity >= LOW)begin 
				tx.print("MEM_BFM");
				$display("\t--> Tx_Count:- %0d",vif.tx_count); 	
			end
		end
	endtask

	task drive_tx(mem_tx tx);
		//@(posedge vif.clk_i);
		@(vif.bfm_cb);
		vif.valid_i 	<= 1'b1;
		vif.bfm_cb.valid_i 	<= 1'b1;
		wait(vif.bfm_cb.ready_o == 1'b1);
		vif.bfm_cb.wr_rd_i 	<= tx.wr_rd;
		vif.bfm_cb.addr_i 	<= tx.addr;
		if(tx.wr_rd == 1) 
			vif.bfm_cb.wdata_i <= tx.wdata;
		else tx.wdata = 0;
		@(vif.bfm_cb);
		if(tx.wr_rd == 0)begin 
			tx.rdata = vif.bfm_cb.rdata_o;
			tx.wdata = 0;
		end
		else tx.rdata = 0;
		vif.bfm_cb.wr_rd_i <= 1'b0;
		vif.bfm_cb.addr_i  <= 1'b0;
		vif.bfm_cb.wdata_i <= 1'b0;
		vif.bfm_cb.valid_i <= 1'b0;
		//if(mem_common::bfm_count == `COUNT)begin 
		//	vif.bfm_cb.wr_rd_i <= 1'b0;
		//	vif.bfm_cb.addr_i  <= 1'b0;
		//	vif.bfm_cb.wdata_i <= 1'b0;
		//	vif.bfm_cb.valid_i <= 1'b0;
		//end
	endtask
endclass
